<?php $__env->startSection('content'); ?>
    <style>
        .card-img-top {
            border-top-left-radius: 1rem;
            border-top-right-radius: 1rem;
            height: 220px;
            object-fit: cover;
        }

        .progress {
            height: 8px;
            border-radius: 5px;
        }

        .verified-icon {
            font-size: 1rem;
            margin-left: 4px;
        }

        .donation-btn {
            border-radius: 0.5rem;
            font-size: 1rem;
        }

        .card {
            border-radius: 1rem;
            overflow: hidden;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
        }
    </style>

    <div class="container py-5" style="margin-top: 80px;">
        <h2 class="text-center mb-5 fw-bold">Daftar Program Donasi</h2>
        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $donasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card shadow-sm h-100">
                        <img src="<?php echo e(asset('storage/' . $donasi->gambar)); ?>" class="card-img-top"
                            alt="<?php echo e($donasi->nama_program); ?>" >

                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title fw-bold"><?php echo e($donasi->nama_program); ?></h5>

                            <!-- Progress Bar -->
                            <?php
                                $terkumpul = $donasi->terkumpul ?? 0;
                                $target = $donasi->unlimited_target ? null : $donasi->target;
                                $progress = $target && $target > 0 ? min(100, ($terkumpul / $target) * 100) : 100;
                            ?>


                            <div class="my-3">
                                <div class="progress">
                                    <div class="progress-bar bg-success" style="width: <?php echo e($progress); ?>%;"></div>
                                </div>
                                <small class="d-block mt-1">
                                    <span
                                        class="text-success fw-semibold">Rp.<?php echo e(number_format($terkumpul, 0, ',', '.')); ?></span>
                                    terkumpul dari
                                    <?php if($donasi->unlimited_target): ?>
                                        <strong class="text-danger">∞ Tak Terbatas</strong>
                                    <?php else: ?>
                                        <strong class="text-danger">Rp.<?php echo e(number_format($target, 0, ',', '.')); ?></strong>
                                    <?php endif; ?>
                                </small>
                            </div>

                            <!-- Info Lembaga -->
                            <div class="d-flex align-items-center mt-auto">
                                <img src="<?php echo e(asset('images/masjidTakhobbar.png')); ?>" alt="Masjid Takhobbar"
                                    class="rounded-circle me-2" width="40" height="40">
                                <span class="fw-medium">Masjid Takhobbar</span>
                                <i class="bi bi-patch-check-fill text-primary verified-icon"></i>
                            </div>

                            <!-- Tombol Donasi -->
                            <?php if($target && $terkumpul >= $target): ?>
                                <button class="btn btn-secondary w-100 mt-3 donation-btn" disabled>
                                    Donasi sudah Tercapai
                                </button>
                            <?php else: ?>
                                <a href="<?php echo e(route('pages.viewDonasi', $donasi->id)); ?>"
                                    class="btn btn-success w-100 mt-3 donation-btn">
                                    Mulai Berdonasi
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="alert alert-info text-center">
                        Belum ada program donasi yang tersedia.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Codingan Laravel\Masjid\MasjidTakhobbar\resources\views/pages/donasi.blade.php ENDPATH**/ ?>