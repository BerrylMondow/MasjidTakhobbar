
<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <h3 class="mb-4">Tabel Keuangan Infaq</h3>

        <!-- Tombol Tambah -->
        <a href="<?php echo e(route('admin.keuangan.add')); ?>" class="btn btn-primary mb-3"><i class="bi bi-plus-circle-fill"></i> Tambah Infaq</a>

        <!-- Tabel Keuangan -->
        <div class="table-responsive">
            <table class="table table-bordered table-hover text-center">
                <thead class="table-success">
                    <tr>
                        <th>Tanggal</th>
                        <th>Nominal</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $infaqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infaq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(\Carbon\Carbon::parse($infaq->tanggal)->format('d-m-Y')); ?></td>
                            <td>Rp. <?php echo e(number_format($infaq->nominal, 0, ',', '.')); ?></td>
                            <td><?php echo e($infaq->keterangan); ?></td>
                            <td>
                                <div class="d-flex justify-content-center align-items-center gap-2">
                                    <a href="<?php echo e(route('admin.keuangan.edit', $infaq->id)); ?>"
                                        class="btn btn-sm btn-warning">Edit</a>

                                    <form action="<?php echo e(route('admin.keuangan.destroy', $infaq->id)); ?>" method="POST"
                                        class="d-inline" onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                    </form>
                                </div>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4">Belum ada data infaq.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Codingan Laravel\Masjid Takhobbar (TA)\MasjidTakhobbar\resources\views/admin/keuangan/list.blade.php ENDPATH**/ ?>