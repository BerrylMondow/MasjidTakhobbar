
<?php $__env->startSection('content'); ?>

<div class="container py-4">
    <h3 class="mb-4"><?php echo e($pageTitle); ?></h3>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Periksa inputan Anda:</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.keuangan.update', $infaq->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="tanggal" class="form-label">Tanggal</label>
            <input type="date" name="tanggal" id="tanggal" class="form-control"
                value="<?php echo e(old('tanggal', $infaq->tanggal)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="nominal" class="form-label">Nominal</label>
            <input type="text" name="nominal" id="nominal" class="form-control"
                value="<?php echo e(old('nominal', number_format($infaq->nominal, 0, ',', '.'))); ?>" required>
        </div>

        <div class="mb-3">
            <label for="keterangan" class="form-label">Keterangan</label>
            <input type="text" name="keterangan" id="keterangan" class="form-control"
                value="<?php echo e(old('keterangan', $infaq->keterangan)); ?>" required>
        </div>

        <button type="submit" class="btn btn-success">Perbarui</button>
        <a href="<?php echo e(route('admin.keuangan.list')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>


<script>
    const nominalInput = document.getElementById('nominal');

    nominalInput.addEventListener('input', function(e) {
        let value = this.value.replace(/\D/g, ''); // Hapus semua bukan angka
        if(value) {
            value = new Intl.NumberFormat('id-ID').format(value);
        }
        this.value = value;
    });

    // Hapus titik sebelum submit
    document.querySelector('form').addEventListener('submit', function() {
        nominalInput.value = nominalInput.value.replace(/\./g, '');
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Codingan Laravel\Masjid Takhobbar (TA)\MasjidTakhobbar\resources\views/admin/keuangan/edit.blade.php ENDPATH**/ ?>