

<?php $__env->startSection('content'); ?>
<div class="container text-center py-5" style="margin-top: 50px;">
    <h3>Silakan Lanjutkan Pembayaran</h3>
    <button id="pay-button" class="btn btn-success">Bayar Sekarang</button>
</div>

<script src="https://app.sandbox.midtrans.com/snap/snap.js"
        data-client-key="<?php echo e(config('midtrans.client_key')); ?>"></script>
<script type="text/javascript">
    var payButton = document.getElementById('pay-button');
    payButton.addEventListener('click', function () {
        window.snap.pay('<?php echo e($snapToken); ?>', {
            onSuccess: function(result) {
                console.log('Success:', result);
                // redirect ke halaman sukses, jika perlu
            },
            onPending: function(result) {
                console.log('Pending:', result);
            },
            onError: function(result) {
                console.log('Error:', result);
            },
            onClose: function() {
                alert('Anda menutup popup pembayaran!');
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Codingan Laravel\Masjid\MasjidTakhobbar\resources\views/pages/snap.blade.php ENDPATH**/ ?>