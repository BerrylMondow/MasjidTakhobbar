

<?php $__env->startSection('content'); ?>
    <style>
        .text-title {
            margin-top: 50px;
        }

        .img-donasi {
            width: 100%;
            height: auto;
            max-width: 1000px;
        }
    </style>

    <div class="container py-5">
        <!-- Judul -->
        <h2 class="text-title text-center fw-bold">AYO BERDONASI</h2>

        <!-- Gambar -->
        <div class="text-center">
            <img src="<?php echo e(asset('storage/' . $donasi->gambar)); ?>" class="img-fluid img-donasi rounded mb-4"
                alt="<?php echo e($donasi->nama_program); ?>">
        </div>

        <!-- Judul Donasi -->
        <h4><?php echo e($donasi->nama_program); ?></h4>

        <!-- Deskripsi -->
        <p><?php echo e($donasi->deskripsi); ?></p>

        <!-- Nama Lembaga -->
        <div class="d-flex align-items-center mb-3">
            <img src="<?php echo e(asset('images/masjidTakhobbar.png')); ?>" width="40" height="40"
                class="rounded-circle me-2" alt="Lembaga">
            <strong>Masjid Takhobbar</strong>
            <i class="bi bi-patch-check-fill ms-2 text-danger verified-icon"></i>
        </div>

        <!-- Progress Donasi -->
        <div class="mb-3">
            <div class="progress" style="height: 10px;">
                <div class="progress-bar bg-success" style="width: <?php echo e($progress); ?>%;"></div>
            </div>
            <small class="text-success fw-bold">
                Rp.<?php echo e(number_format($terkumpul, 0, ',', '.')); ?>

            </small>
            terkumpul dari
            <?php if($donasi->unlimited_target): ?>
                <strong>∞ Tak Terbatas</strong>
            <?php else: ?>
                <strong>Rp.<?php echo e(number_format($target, 0, ',', '.')); ?></strong>
            <?php endif; ?>
        </div>

        <!-- Form Donasi dengan tombol Snap -->
        <form id="form-donasi" novalidate>
            <div class="mb-3">
                <input type="text" name="nama" id="nama" class="form-control" placeholder="Masukkan Nama"
                    required>
                <div class="invalid-feedback">
                    Silakan masukkan nama Anda!
                </div>
            </div>

            <div class="mb-3">
                <input type="text" name="nominal" id="nominal" class="form-control"
                    placeholder="Masukkan Nominal (Min. Rp10.000)" required>

                <div class="invalid-feedback">
                    Silakan masukkan nominal donasi minimal Rp10.000!
                </div>
            </div>

            <div class="mb-3">
                <input type="email" name="email" id="email" class="form-control" placeholder="Masukkan Email"
                    required>

                <div class="invalid-feedback">
                    Silakan masukkan email yang valid dan tidak mengandung karakter . / < ? , : </div>
                </div>

                <button type="button" id="pay-button" class="btn btn-success w-100">Bayar Donasi</button>
        </form>
    </div>

    <!-- Midtrans Snap.js -->
    <script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?php echo e(config('midtrans.client_key')); ?>">
    </script>

    <script>
        function formatRupiah(angka) {
            let number_string = angka.replace(/[^,\d]/g, '').toString(),
                split = number_string.split(','),
                sisa = split[0].length % 3,
                rupiah = split[0].substr(0, sisa),
                ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            if (ribuan) {
                let separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }
            rupiah = split[1] !== undefined ? rupiah + ',' + split[1] : rupiah;
            return rupiah;
        }

        document.getElementById('nominal').addEventListener('input', function(e) {
            this.value = formatRupiah(this.value);
        });

        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('form-donasi');
            const payButton = document.getElementById('pay-button');

            payButton.addEventListener('click', function(event) {
                if (!form.checkValidity()) {
                    form.classList.add('was-validated');
                    return;
                }

                const nama = document.getElementById('nama').value;
                const nominal = document.getElementById('nominal').value.replace(/\./g, '');
                const email = document.getElementById('email').value;

                fetch("/donasi/bayar", {
                        method: "POST",
                        headers: {
                            "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>",
                            "Content-Type": "application/json",
                        },
                        body: JSON.stringify({
                            donasi_id: "<?php echo e($donasi->id); ?>",
                            nama: nama,
                            nominal: nominal,
                            email: email
                        }),
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.snapToken) {
                            window.snap.pay(data.snapToken, {
                                onSuccess: function(result) {
                                    window.location.href = "<?php echo e(route('donasi')); ?>";
                                },
                                onPending: function(result) {
                                    console.log('Pending:', result);
                                },
                                onError: function(result) {
                                    console.log('Error:', result);
                                }
                            });
                        } else {
                            alert("Gagal membuat Snap Token. Silakan coba lagi.");
                        }
                    })
                    .catch(error => {
                        console.error(error);
                        alert("Terjadi kesalahan. Silakan coba lagi.");
                    });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Codingan Laravel\Masjid\MasjidTakhobbar\resources\views/pages/viewDonasi.blade.php ENDPATH**/ ?>