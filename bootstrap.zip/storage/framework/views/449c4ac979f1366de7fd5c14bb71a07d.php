<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo e($pageTitle ?? 'Admin Login'); ?></title>
  <link rel="icon" type="image/x-icon" href="<?php echo e(Vite::asset('resources/img/masjidTakhobbar.png')); ?>">
  <?php echo app('Illuminate\Foundation\Vite')('resources/sass/app.scss'); ?>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/style.css'); ?>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
  <?php echo $__env->yieldContent('content'); ?>

  <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH E:\Codingan Laravel\Masjid\MasjidTakhobbar\resources\views/admin/layout/appAuth.blade.php ENDPATH**/ ?>