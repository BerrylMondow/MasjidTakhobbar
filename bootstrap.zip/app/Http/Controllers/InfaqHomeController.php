<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Infaq;

class InfaqHomeController extends Controller
{
   //
}
